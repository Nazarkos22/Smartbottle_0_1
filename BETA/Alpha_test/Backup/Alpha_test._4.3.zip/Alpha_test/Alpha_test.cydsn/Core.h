/* ========================================
 *
     Code is written by:
           Kotliar Nazarii (NKOT)     
 *
 * ========================================
*/
#ifndef __CORE_H_
    #define __CORE_H_
#include "project.h"
#include "Config_u.h"
     
void CapSense_Processing(void);

void Flash_Processing(void);

/* [] END OF FILE */
 #endif